create definer = root@localhost view film_list as
select `yks`.`film`.`film_id`                                                                          AS `FID`,
       `yks`.`film`.`title`                                                                            AS `title`,
       `yks`.`film`.`description`                                                                      AS `description`,
       `yks`.`category`.`name`                                                                         AS `category`,
       `yks`.`film`.`rental_rate`                                                                      AS `price`,
       `yks`.`film`.`length`                                                                           AS `length`,
       `yks`.`film`.`rating`                                                                           AS `rating`,
       group_concat(concat(`yks`.`actor`.`first_name`, ' ', `yks`.`actor`.`last_name`) separator ', ') AS `actors`
from ((((`yks`.`category` left join `yks`.`film_category` on ((`yks`.`category`.`category_id` = `yks`.`film_category`.`category_id`))) left join `yks`.`film` on ((`yks`.`film_category`.`film_id` = `yks`.`film`.`film_id`))) join `yks`.`film_actor` on ((`yks`.`film`.`film_id` = `yks`.`film_actor`.`film_id`)))
       join `yks`.`actor` on ((`yks`.`film_actor`.`actor_id` = `yks`.`actor`.`actor_id`)))
group by `yks`.`film`.`film_id`;

