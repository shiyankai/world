create definer = root@localhost view customer_list as
select `cu`.`customer_id`                               AS `ID`,
       concat(`cu`.`first_name`, ' ', `cu`.`last_name`) AS `name`,
       `a`.`address`                                    AS `address`,
       `a`.`postal_code`                                AS `zip code`,
       `a`.`phone`                                      AS `phone`,
       `yks`.`city`.`city`                              AS `city`,
       `yks`.`country`.`country`                        AS `country`,
       if(`cu`.`active`, 'active', '')                  AS `notes`,
       `cu`.`store_id`                                  AS `SID`
from (((`yks`.`customer` `cu` join `yks`.`address` `a` on ((`cu`.`address_id` = `a`.`address_id`))) join `yks`.`city` on ((`a`.`city_id` = `yks`.`city`.`city_id`)))
       join `yks`.`country` on ((`yks`.`city`.`country_id` = `yks`.`country`.`country_id`)));

