create definer = root@localhost view staff_list as
select `s`.`staff_id`                                 AS `ID`,
       concat(`s`.`first_name`, ' ', `s`.`last_name`) AS `name`,
       `a`.`address`                                  AS `address`,
       `a`.`postal_code`                              AS `zip code`,
       `a`.`phone`                                    AS `phone`,
       `yks`.`city`.`city`                            AS `city`,
       `yks`.`country`.`country`                      AS `country`,
       `s`.`store_id`                                 AS `SID`
from (((`yks`.`staff` `s` join `yks`.`address` `a` on ((`s`.`address_id` = `a`.`address_id`))) join `yks`.`city` on ((`a`.`city_id` = `yks`.`city`.`city_id`)))
       join `yks`.`country` on ((`yks`.`city`.`country_id` = `yks`.`country`.`country_id`)));

