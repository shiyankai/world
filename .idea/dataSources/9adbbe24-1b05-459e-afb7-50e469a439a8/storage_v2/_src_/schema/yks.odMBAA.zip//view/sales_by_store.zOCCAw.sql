create definer = root@localhost view sales_by_store as
select concat(`c`.`city`, ',', `cy`.`country`)        AS `store`,
       concat(`m`.`first_name`, ' ', `m`.`last_name`) AS `manager`,
       sum(`p`.`amount`)                              AS `total_sales`
from (((((((`yks`.`payment` `p` join `yks`.`rental` `r` on ((`p`.`rental_id` = `r`.`rental_id`))) join `yks`.`inventory` `i` on ((`r`.`inventory_id` = `i`.`inventory_id`))) join `yks`.`store` `s` on ((`i`.`store_id` = `s`.`store_id`))) join `yks`.`address` `a` on ((`s`.`address_id` = `a`.`address_id`))) join `yks`.`city` `c` on ((`a`.`city_id` = `c`.`city_id`))) join `yks`.`country` `cy` on ((`c`.`country_id` = `cy`.`country_id`)))
       join `yks`.`staff` `m` on ((`s`.`manager_staff_id` = `m`.`staff_id`)))
group by `s`.`store_id`
order by `cy`.`country`, `c`.`city`;

